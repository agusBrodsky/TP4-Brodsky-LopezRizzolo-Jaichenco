import config from '../dbconfig.js'
import sql from 'mssql';

class peliculaService {
    
    static getPartes = async (IdPelicula) => {
        let returnEntity = null;
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pId', sql.Int, IdPelicula)
                .query('SELECT personaje.IdPersonaje, personaje.Nombre,personaje.Imagen,personaje.Edad,personaje.Peso,personaje.Historia FROM personaje JOIN pelicula ON pelicula.IdPelicula = personaje.IdPelicula WHERE personaje.IdPelicula = @pId');
            returnEntity = result.recordsets[0];
        } catch (error) {
            console.log(error);
        }
        console.log(returnEntity);
        return returnEntity;
    }

    static getAll = async () => {
        let returnEntity = null;
        console.log('Estoy en: PeliculaService.GetAll');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .query('SELECT * FROM Pelicula');
            returnEntity = result.recordsets[0];
        } catch (error) {
            console.log(error);
        }
        return returnEntity;
    }

    static getById = async (IdPelicula) => {
        {
            let returnEntity = null;
            //console.log(`Estoy en: peliculaService.GetById ${id}`);
            try {
                let pool = await sql.connect(config);
                let result = await pool.request()
                    .input('pId', sql.Int, IdPelicula)
                    .query('SELECT * FROM Pelicula WHERE IdPelicula = @pId');
                returnEntity = result.recordsets[0][0];
            } catch (error) {
                console.log(error);
            }
            return returnEntity;

        }
    }

    static insert = async (pelicula) => {
        let rowsAffected = 0;
        console.log('Estoy en: peliculaService.insert(pelicula)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pImagen', pelicula.Imagen)
                .input('pTitulo', pelicula.Titulo)
                .input('pFechaDeCreacion', pelicula.FechaDeCreacion)
                .input('pCalificacion', pelicula.Calificacion)
                .query('INSERT INTO Pelicula (Imagen, Titulo, FechaDeCreacion ,Calificacion) VALUES (@pImagen, @pTitulo, @pFechaDeCreacion, @pCalificacion)');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log(error)
        }
        return rowsAffected;
    }

    static update = async (pelicula) => {
        let rowsAffected = 0;
        const { IdPelicula, Imagen, Titulo, FechaDeCreacion, Calificacion } = pelicula;

        console.log('Estoy en: peliculaService.update(pelicula)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pIdPelicula', IdPelicula)
                .input('pImagen', Imagen)
                .input('pTitulo', Titulo)
                .input('pFechaDeCreacion', FechaDeCreacion)
                .input('pCalificacion', Calificacion)

                .query('UPDATE Pelicula SET Imagen = @pImagen ,Titulo = @pTitulo, FechaDeCreacion = @pFechaDeCreacion, Calificacion = @pCalificacion WHERE IdPelicula = @pIdPelicula;');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log(error)
        }
        return rowsAffected;
    }

    static deleteById = async (id) => {
        let rowsAffected = 0;
        console.log('Estoy en: peliculaService.deleteById(id)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pId', sql.Int, id)
                .query('DELETE FROM Pelicula WHERE IdPelicula = @pId');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log(error)
        }
        return rowsAffected;

    }
}

export default peliculaService;
