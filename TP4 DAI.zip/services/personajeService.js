import config from '../dbconfig.js'
import sql from 'mssql';

class personajeService {
    
    static getAll = async () => {
        let returnEntity = null;
        console.log('Estoy en: personajeService.GetAll');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .query('SELECT personaje.*,pelicula.Titulo FROM personaje JOIN pelicula ON pelicula.IdPelicula = personaje.IdPelicula');
            returnEntity = result.recordsets[0];
        } catch (error) {
            console.log(error);
        }
        return returnEntity;
    }
    static getById = async (nombre) => {
        {
            let returnEntity = null;
            //console.log(`Estoy en: personajeService.GetById22 `);
            try {
                let pool = await sql.connect(config);
                let result = await pool.request()
                    .input('pNombre', sql.VarChar, nombre)
                    // PUNTO 5 .query('SELECT personaje.*,pelicula.Titulo FROM personaje JOIN pelicula ON pelicula.IdPelicula = personaje.IdPelicula WHERE IdPersonaje = @pId');
                    .query('SELECT * FROM personaje WHERE Nombre = @pNombre') // PUNTO 6
                returnEntity = result.recordsets[0][0];
            } catch (error) {
                console.log(error);
            }
            console.log(returnEntity);
            return returnEntity;

        }
    }

    static insert = async (personaje) => {
        let rowsAffected = 0;
        console.log('Estoy en: personajeService.insert(personaje)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pIdPelicula', personaje.IdPelicula)
                .input('pNombre', personaje.Nombre)
                .input('pImagen', personaje.Imagen)
                .input('pEdad', personaje.Edad)
                .input('pPeso', personaje.Peso)
                .input('pHistoria', personaje.Historia)
                .query('INSERT INTO personaje (IdPelicula,Nombre, Imagen, Edad, Peso , Historia) VALUES (@pIdPelicula,@pNombre, @pImagen, @pEdad, @pPeso, @pHistoria)');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log("error");
        }
        return rowsAffected;
    }

    static update = async (personaje) => {
        let rowsAffected = 0;
        const { IdPersonaje, Nombre, Imagen, Edad, Peso, Historia } = personaje;
        console.log('Estoy en: personajeService.update(personaje)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pId', IdPersonaje)
                .input('pNombre', Nombre)
                .input('pImagen', Imagen)
                .input('pEdad', Edad)
                .input('pPeso', Peso)
                .input('pHistoria', Historia)

                .query('UPDATE personaje SET Nombre = @pNombre ,Imagen = @pImagen , Edad= @pEdad, Peso = @pPeso, Historia = @pHistoria WHERE IdPersonaje = @pId;');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log(error)
        }
        return rowsAffected;
    }

    static deleteById = async (id) => {
        let rowsAffected = 0;
        console.log('Estoy en: personajeService.deleteById(id)');
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pId', sql.Int, id)
                .query('DELETE FROM personaje WHERE IdPersonaje = @pId');
            rowsAffected = result.rowsAffected;
        } catch (error) {
            console.log(error)
        }
        return rowsAffected;
    }
}
export default personajeService;
