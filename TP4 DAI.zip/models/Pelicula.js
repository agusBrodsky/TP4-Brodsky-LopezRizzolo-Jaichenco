class Pelicula{
    IdPelicula;
    Imagen;
    Titulo;
    FechaDeCreacion;
    Calificacion;
}
export default Pelicula;