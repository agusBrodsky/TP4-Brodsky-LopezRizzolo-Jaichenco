class Personaje {
    IdPersonaje;
    IdPelicula;
    Nombre;
    Imagen;
    Edad;
    Peso;
    Historia;
}
export default Personaje;